require 'bee_task'

module Bee
  
  module Task
  
    # Package for hello tasks (tasks with package "hello").
    class Hello < Package
    
      # Sample say task that prints greeting message on console.
      # 
      # - who: who to greet.
      # 
      # Example
      # 
      #  - hello.say: "World"
      def say(who)
        puts "Hello #{who}!"
      end

    end

  end

end
